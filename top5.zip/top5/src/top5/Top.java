package top5;
import java.io.*;
import org.json.*;
public class Top {
	public static void main(String[] args) {
		
		BufferedReader reader = null;
		
		String top1[] = new String [5];
		String top2[] = new String [5];
		String top3[] = new String [5];
		String top4[] = new String [5];
		double a1[]= {0,0,0,0,0};
		double a2[]= {0,0,0,0,0};
		double a3[]= {0,0,0,0,0};
		double a4[]= {0,0,0,0,0};
		File file=new File("东二环泰禾广场美食.txt");
		try {
			
			StringBuffer sbf = new StringBuffer();
			reader = new BufferedReader(new FileReader(file));
			String tempStr;
			while ((tempStr = reader.readLine()) != null) {
				sbf.append(tempStr);
			}
			reader.close();
			//System.out.println(sbf);
			try {
				JSONArray ja = new JSONArray(sbf.toString());
				int n=ja.length();
				for(int i=0;i<n;i++) {
					JSONObject x = new JSONObject(ja.getString(i));
					if(x.getInt("price")<50) {
						JSONArray xx = new JSONArray(x.getString("level"));
						if(xx.length()>2) {
						double p=xx.getDouble(1);
						double q=xx.getDouble(2);
						double y=p*q;
						if(y>a1[0]) {
							a1[4]=a1[3];
							a1[3]=a1[2];
							a1[2]=a1[1];
							a1[1]=a1[0];
							a1[0]=y;
							top1[4]=top1[3];
							top1[3]=top1[2];
							top1[2]=top1[1];
							top1[1]=top1[0];
							top1[0]=x.toString();
							
						}
						else if(y>a1[1]) {
							a1[4]=a1[3];
							a1[3]=a1[2];
							a1[2]=a1[1];
							a1[1]=y;
							top1[4]=top1[3];
							top1[3]=top1[2];
							top1[2]=top1[1];
							top1[1]=x.toString();
						}
						else if(y>a1[2]) {
							a1[4]=a1[3];
							a1[3]=a1[2];
							a1[2]=y;
							top1[4]=top1[3];
							top1[3]=top1[2];
							top1[2]=x.toString();
						}
						else if(y>a1[3]) {
							a1[4]=a1[3];
							a1[3]=y;
							top1[4]=top1[3];
							top1[3]=x.toString();
						}
						else if(y>a1[4]) {
							a1[4]=y;
							top1[4]=x.toString();
						}}
					}
					else if(x.getInt("price")>=50&&x.getInt("price")<100) {
						JSONArray xx = new JSONArray(x.getString("level"));
						if(xx.length()>2) {
						double p=xx.getDouble(1);
						double q=xx.getDouble(2);
						double y=p*q;
						if(y>a2[0]) {
							a2[4]=a2[3];
							a2[3]=a2[2];
							a2[2]=a2[1];
							a2[1]=a2[0];
							a2[0]=y;
							top2[4]=top2[3];
							top2[3]=top2[2];
							top2[2]=top2[1];
							top2[1]=top2[0];
							top2[0]=x.toString();
						}
						else if(y>a2[1]) {
							a2[4]=a2[3];
							a2[3]=a2[2];
							a2[2]=a2[1];
							a2[1]=y;
							top2[4]=top2[3];
							top2[3]=top2[2];
							top2[2]=top2[1];
							top2[1]=x.toString();
						}
						else if(y>a2[2]) {
							a2[4]=a2[3];
							a2[3]=a2[2];
							a2[2]=y;
							top2[4]=top2[3];
							top2[3]=top2[2];
							top2[2]=x.toString();
						}
						else if(y>a2[3]) {
							a2[4]=a2[3];
							a2[3]=y;
							top2[4]=top2[3];
							top2[3]=x.toString();
						}
						else if(y>a2[4]) {
							a2[4]=y;
							top2[4]=x.toString();
						}}
					}
					else if(x.getInt("price")>=100&&x.getInt("price")<200) {
						JSONArray xx = new JSONArray(x.getString("level"));
						if(xx.length()>2) {
						double p=xx.getDouble(1);
						double q=xx.getDouble(2);
						double y=p*q;
						if(y>a3[0]) {
							a3[4]=a3[3];
							a3[3]=a3[2];
							a3[2]=a3[1];
							a3[1]=a3[0];
							a3[0]=y;
							top3[4]=top3[3];
							top3[3]=top3[2];
							top3[2]=top3[1];
							top3[1]=top3[0];
							top3[0]=x.toString();
						}
						else if(y>a3[1]) {
							a3[4]=a3[3];
							a3[3]=a3[2];
							a3[2]=a3[1];
							a3[1]=y;
							top3[4]=top3[3];
							top3[3]=top3[2];
							top3[2]=top3[1];
							top3[1]=x.toString();
						}
						else if(y>a3[2]){
							a3[4]=a3[3];
							a3[3]=a3[2];
							a3[2]=y;
							top3[4]=top3[3];
							top3[3]=top3[2];
							top3[2]=x.toString();
						}
						else if(y>a3[3]) {
							a3[4]=a3[3];
							a3[3]=y;
							top3[4]=top3[3];
							top3[3]=x.toString();
						}
						else if(y>a3[4]) {
							a3[4]=y;
							top3[4]=x.toString();
						}}
					}
					else if(x.getInt("price")>=200) {
						JSONArray xx = new JSONArray(x.getString("level"));
						if(xx.length()>2) {
						double p=xx.getDouble(1);
						double q=xx.getDouble(2);
						double y=p*q;
						if(y>a4[0]) {
							a4[4]=a4[3];
							a4[3]=a4[2];
							a4[2]=a4[1];
							a4[1]=a4[0];
							a4[0]=y;
							top4[4]=top4[3];
							top4[3]=top4[2];
							top4[2]=top4[1];
							top4[1]=top4[0];
							top4[0]=x.toString();
						}
						else if(y>a4[1]) {
							a4[4]=a4[3];
							a4[3]=a4[2];
							a4[2]=a4[1];
							a4[1]=y;
							top4[4]=top4[3];
							top4[3]=top4[2];
							top4[2]=top4[1];
							top4[1]=x.toString();
						}
						else if(y>a4[2]) {
							a4[4]=a4[3];
							a4[3]=a4[2];
							a4[2]=y;
							top4[4]=top4[3];
							top4[3]=top4[2];
							top4[2]=x.toString();
						}
						else if(y>a4[3]) {
							a4[4]=a4[3];
							a4[3]=y;
							top4[4]=top4[3];
							top4[3]=x.toString();
						}
						else if(y>a4[4]) {
							a4[4]=y;
							top4[4]=x.toString();
						}
						}
						
					}
				}
				
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			
			System.out.println("<50");
				for(int j=0;j<5;j++) {
	    			System.out.println(top1[j]);
	    		}
				System.out.println("50-100");
				for(int j=0;j<5;j++) {
	    			System.out.println(top2[j]);
	    		}
				System.out.println("100-200");
				for(int j=0;j<5;j++) {
	    			System.out.println(top3[j]);
	    		}
				System.out.println(">200");
				for(int j=0;j<5;j++) {
	    			System.out.println(top4[j]);
	    		}
			
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
		
		
		
		finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	}
}
